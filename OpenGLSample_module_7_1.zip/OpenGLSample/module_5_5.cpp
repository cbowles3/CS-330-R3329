/*
* Chris Bowles
* CS-330-R3329
* 2/11/24
*
* Module 5-5: This milestone uses source code from the previous milestone 4-5 and tutorial 05_05 to create 3D objects
* in a scene and add texture to them by loading image files and creating textures inside the code.
* 
* Major changes from the previous milestone have been the re-writing of elements inside the UCreateCylinderMesh() function
* to account for texture coordinates instead of R,G,B,A values. This led us to change the STRIDE value to 5 and we found our
* texture coordinates for each face of the cylinder by dividing the current edge by the number of sides to get a fractional
* value (texture coordinates are 0.0 to 1.0).
* 
* We duplicated and modified the UCreatePrism() function to create cones instead (cylinders with a radius of zero on the top).
* This was not as much work as expected thanks to the source code for prisms provided by Professor Gray.
* 
* We modified the fragment shader source code to accept 2 textures as well as a boolean value to identify when the extra
* texture should be added. This boolean is manually triggered in URender() as needed. Our project utilizes this when texturing
* the grassy area with a dirt path overlayed.
* 
* Methods have been added to Create and Destroy textures at the beginning and ending of the main() function respectively.
* 
* We have added a gUVScale vector that we can use to scale our texture depending on the size of the object to prevent unnecessary
* stretching or tearing. We use this several times in URender() to scale the stone texture used on walls and towers. Walls need
* the texture scaled wider, and the towers taller for example to keep the stones at a similar shape.
* 
* Credit for Blue roof texture goes to: Althaj (https://opengameart.org/content/blue-roof)
*/

#include <glad/glad.h>

#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION

#include "stb_image.h"

#include <glm/glm.hpp>

#include <glm/gtc/matrix_transform.hpp>

#include <glm/gtx/transform.hpp>

#include <glm/gtc/type_ptr.hpp>

#include "shader.h"

#include "camera.h"

#include <iostream>

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Module 5-5"; // Macro for window title

    // offset to use to encompass vertex position (3) and textures (2)
    const int STRIDE = 5;

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handle for the vertex buffer object(s)
        GLuint nIndices;    // Number of indices of the mesh
        GLuint nVertices;   // Number of vertices (for some meshes)
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Plane mesh data
    GLMesh gPlaneMesh;
    // Cube mesh data
    GLMesh gCubeMesh;
    // Cylinder mesh data
    GLMesh gCylinderMesh;
    // Cone mesh data
    GLMesh gConeMesh;

    // Texture
    GLuint gTextureId1, gTextureId2, gTextureId3, gTextureId4;
    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader program
    GLuint gProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.5f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // For perspective/orthographic projection switch
    bool perspectiveSwitch = true;

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreatePrism(GLfloat verts[], GLushort indices[], int numSides, float radius, float halfLen);
void UCreateCylinderMesh(GLMesh& mesh);
void UCreateCone(GLfloat verts[], GLushort indices[], int numSides, float radius, float Len);
void UCreateConeMesh(GLMesh& mesh);
void UCreatePlaneMesh(GLMesh& mesh);
void UCreateCubeMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 2) in vec2 textureCoordinate; // Vertex data Vertex Attrib Pointer 2

    out vec2 vertexTextureCoordinate; // variable to transfer color data to the fragment shader

    //Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
        vertexTextureCoordinate = textureCoordinate;
    }
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate;

    out vec4 fragmentColor;

    // adding second texture and bool for multiple textures
    uniform sampler2D uTexture;
    uniform sampler2D uTexture2;
    uniform bool multipleTextures;
    uniform vec2 uvScale;

    void main()
    {
        fragmentColor = texture(uTexture, vertexTextureCoordinate * uvScale);
        // boolean is manually toggled in Urender() when needed to apply layered texture
        if (multipleTextures) {
            vec4 extraTexture = texture(uTexture2, vertexTextureCoordinate * uvScale);
            if (extraTexture.a != 0.0) {
                fragmentColor = extraTexture;
            }
        }
    }
);


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create meshes
    UCreatePlaneMesh(gPlaneMesh); // Calls the function to create the Vertex Buffer Object
    UCreateCubeMesh(gCubeMesh);
    UCreateCylinderMesh(gCylinderMesh);
    UCreateConeMesh(gConeMesh);

    // Create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    // Load textures
    const char* texFilename = "grass.jpg";
    if (!UCreateTexture(texFilename, gTextureId1))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    const char* tex2Filename = "dirt_path.png";
    if (!UCreateTexture(tex2Filename, gTextureId2))
    {
        cout << "Failed to load texture " << tex2Filename << endl;
        return EXIT_FAILURE;
    }

    const char* tex3Filename = "stone.jpg";
    if (!UCreateTexture(tex3Filename, gTextureId3))
    {
        cout << "Failed to load texture " << tex3Filename << endl;
        return EXIT_FAILURE;
    }

    const char* tex4Filename = "blue_roof.png";
    if (!UCreateTexture(tex4Filename, gTextureId4))
    {
        cout << "Failed to load texture " << tex4Filename << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // We set the extra texture as texture unit 1
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture2"), 1);


    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Check for specific key events (Projection switch, etc.)
        glfwSetKeyCallback(gWindow, key_callback);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gCubeMesh);
    UDestroyMesh(gCylinderMesh);
    UDestroyMesh(gConeMesh);

    // Release texture
    UDestroyTexture(gTextureId1);
    UDestroyTexture(gTextureId2);
    UDestroyTexture(gTextureId3);
    UDestroyTexture(gTextureId4);

    // Release shader program
    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers

    // ---------------------------------------

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))

    {

        std::cout << "Failed to initialize GLAD" << std::endl;

        return -1;

    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    // Implementing code for key presses 'Q' and 'E' for up and down camera movement respectively
    /* Modifying code in camera.h as follows to calculate for camera position:
    *
    * if (direction == UP)
            Position += Up * velocity;
        if (direction == DOWN)
            Position -= Up * velocity;
    */

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
}


// callback function executes in main loop; checks for certain key events
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS) {
        // COUT statements for testing purpose
        cout << "P pressed" << endl;
        // Switches boolean value to opposite of current value
        if (perspectiveSwitch == true) {
            perspectiveSwitch = false;
            cout << "projection switched to orthographic" << endl;
        }
        else if (perspectiveSwitch == false) {
            perspectiveSwitch = true;
            cout << "projection switched back to perspective" << endl;
        }
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    // ProcessMouseScroll() function now determines movement speed of camera; commented changes in camera.h file
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Function called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // 1. Scales the object by 1
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates shape by 0 degrees in the y axis
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // camera/view transformation
    glm::mat4 view = gCamera.GetViewMatrix();

    glm::mat4 projection;

    // If statement to capture the projection matrix desired (defaults to perspective)
    // Bool value 'perspectiveSwitch' is determined in the key_callback() function
    if (perspectiveSwitch == true) {
        // Creates a perspective projection
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        // Creates an orthographic projection
        projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 50.0f);
    }

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Points to Texture scale we declared in namespace
    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Activate boolean that identifies multiple textures
    // This lets the fragment shader know that we are working with multiple textures
    GLuint multipleTexturesLoc = glGetUniformLocation(gProgramId, "multipleTextures");
    glUniform1i(multipleTexturesLoc, true);


    ////////////
    // PLANES //
    ////////////
    
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPlaneMesh.vao);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId1);
    // extra texture
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId2);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Second plane translated to the left
    translation = glm::translate(glm::vec3(-1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Toggle multiple texture off to prevent extra texture being added
    glUniform1i(multipleTexturesLoc, false);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Third plane translated to the right
    translation = glm::translate(glm::vec3(1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // END PLANES //
 

    ///////////
    // CUBES //
    ///////////
    
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // Scale object in half on the z-axis
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 0.5f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale up textures
    gUVScale = glm::vec2(10.0f, 5.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // bind textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Second cube translated left
    translation = glm::translate(glm::vec3(-1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);
           
    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // END CUBES//
    
    
    ///////////////
    // CYLINDERS //
    ///////////////
    
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCylinderMesh.vao);

    // Scale and Translate
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.75f, 0.501f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale textures
    gUVScale = glm::vec2(8.0f, 10.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate second cylinder
    rotation = glm::rotate(90.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-0.75f, 0.501f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate third cylinder
    scale = glm::scale(glm::vec3(1.0f, 0.6f, 1.0f));
    translation = glm::translate(glm::vec3(1.3f, 0.301f, 0.2f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale textures
    gUVScale = glm::vec2(8.0f, 6.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate fourth cylinder
    translation = glm::translate(glm::vec3(-1.3f, 0.301f, 0.2f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // END CYLINDERS //

    ///////////
    // CONES //
    ///////////

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gConeMesh.vao);

    // Scale and Translate
    translation = glm::translate(glm::vec3(0.75f, 1.001f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale textures
    gUVScale = glm::vec2(3.0f, 2.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Bind textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId4);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gConeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate
    translation = glm::translate(glm::vec3(-0.75f, 1.001f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gConeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Reset texture scale
    gUVScale = glm::vec2(1.0f, 1.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // END CONES //

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// creates a prism based on the number of side turned in; assumes a stride of 5
void UCreatePrism(GLfloat verts[], GLushort indices[], int numSides, float radius, float halfLen)
{
    // create constant for 2PI used in calculations
    const float TWO_PI = 2.0f * 3.1415926f;
    const float radiansPerSide = TWO_PI / numSides;

    // value to increment after each vertex is created
    int currentVertex = 0;

    // in this  algorithm, vertex zero is the top center vertex, and vertex one is the bottom center
    // each is offset by the step size
    verts[0] = 0.0f;    // 0 x
    verts[1] = halfLen; // 0 y
    verts[2] = 0.0f;    // 0 z
    verts[3] = 1.0f;    // 0 s
    verts[4] = 1.0f;    // 0 t
    currentVertex++;

    verts[5] = 0.0f;    // 1 x
    verts[6] = -halfLen;// 1 y
    verts[7] = 0.0f;    // 1 z
    verts[8] = 0.0f;   // 1 s
    verts[9] = 0.0f;   // 1 t
    currentVertex++;

    // variable to keep track of every triangle added to indices
    int currentTriangle = 0;

    // note: the number of flat sides is equal to the number of edge on the sides
    for (int edge = 0; edge < numSides; edge++)
    {
        // calculate theta, which is the angle from the center point to the next vertex
        float theta = ((float)edge) * radiansPerSide;

        // top triangle first perimeter vertex
        verts[currentVertex * STRIDE + 0] = radius * cos(theta);    // x
        verts[currentVertex * STRIDE + 1] = halfLen;                // y
        verts[currentVertex * STRIDE + 2] = radius * sin(theta);    // z
        verts[currentVertex * STRIDE + 3] = (float)edge / (float)numSides;  // s
        verts[currentVertex * STRIDE + 4] = 0.0f;                   // t
        currentVertex++;

        // bottom triangle first perimeter vertex
        verts[currentVertex * STRIDE + 0] = radius * cos(theta);    // x
        verts[currentVertex * STRIDE + 1] = -halfLen;               // y
        verts[currentVertex * STRIDE + 2] = radius * sin(theta);    // z
        verts[currentVertex * STRIDE + 3] = (float)edge / (float)numSides;  // s
        verts[currentVertex * STRIDE + 4] = 1.0f;                   // t
        currentVertex++;

        if (edge > 0)
        {
            // now to create the indices for the triangles
            // top triangle
            indices[(3 * currentTriangle) + 0] = 0;                 // center of top of prism
            indices[(3 * currentTriangle) + 1] = currentVertex - 4; // upper left vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 2; // upper right vertex of side
            currentTriangle++;

            // bottom triangle
            indices[(3 * currentTriangle) + 0] = 1;                 // center of bottom of prism
            indices[(3 * currentTriangle) + 1] = currentVertex - 3; // bottom left vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 1; // bottom right vertex of side
            currentTriangle++;

            // triangle for 1/2 retangular side
            indices[(3 * currentTriangle) + 0] = currentVertex - 4; // upper left vertex of side
            indices[(3 * currentTriangle) + 1] = currentVertex - 3; // bottom left vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 1; // bottom right vertex of side
            currentTriangle++;

            // triangle for second 1/2 retangular side
            indices[(3 * currentTriangle) + 0] = currentVertex - 1; // bottom right vertex of side
            indices[(3 * currentTriangle) + 1] = currentVertex - 2; // upper right vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 4; // upper left vertex of side
            currentTriangle++;

        }

    }

    // now, just need to wire up the last side
    // now to create the indices for the triangles
    // top triangle
    indices[(3 * currentTriangle) + 0] = 0;                 // center of top of prism
    indices[(3 * currentTriangle) + 1] = currentVertex - 2; // upper left vertex of side
    indices[(3 * currentTriangle) + 2] = 2;                 // first upper left vertex created, now right
    currentTriangle++;

    // bottom triangle
    indices[(3 * currentTriangle) + 0] = 1;                 // center of bottom of prism
    indices[(3 * currentTriangle) + 1] = currentVertex - 1; // bottom left vertex of side
    indices[(3 * currentTriangle) + 2] = 3;                 // first bottom left vertex created, now right
    currentTriangle++;

    // triangle for 1/2 retangular side
    indices[(3 * currentTriangle) + 0] = currentVertex - 2; // upper left vertex of side
    indices[(3 * currentTriangle) + 1] = currentVertex - 1; // bottom left vertex of side
    indices[(3 * currentTriangle) + 2] = 3;                 // bottom right vertex of side
    currentTriangle++;

    // triangle for second 1/2 retangular side
    indices[(3 * currentTriangle) + 0] = 3;                 // bottom right vertex of side
    indices[(3 * currentTriangle) + 1] = 2;                 // upper right vertex of side
    indices[(3 * currentTriangle) + 2] = currentVertex - 2; // upper left vertex of side
    currentTriangle++;

}


// Code for creating Cylinder (rectangular prism w many sides) mesh
void UCreateCylinderMesh(GLMesh& mesh) {

    // Number of sides for prism
    const int NUM_SIDES = 100;

    // Number of vertices
    const int NUM_VERTICES = STRIDE * (2 + (2 * NUM_SIDES));

    // Number of indices
    const int NUM_INDICES = 12 * NUM_SIDES;

    // Position and Texture data
    GLfloat verts[NUM_VERTICES];

    // Index data
    GLushort indices[NUM_INDICES];

    // Fill verts and indices arrays
    UCreatePrism(verts, indices, NUM_SIDES, 0.2f, 0.5f);

    // Verify stride is correct
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;
    if (STRIDE != floatsPerVertex + floatsPerUV) {
        exit(EXIT_FAILURE);
    }

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
}


// Creates a cone based on the number of sides, also assumes stride of 5
void UCreateCone(GLfloat verts[], GLushort indices[], int numSides, float radius, float Len) {

    // create constant for 2PI used in calculations
    const float TWO_PI = 2.0f * 3.1415926f;
    const float radiansPerSide = TWO_PI / numSides;

    // value to increment after each vertex is created
    int currentVertex = 0;

    // in this  algorithm, vertex zero is the top center vertex, and vertex one is the bottom center
    // each is offset by the step size
    verts[0] = 0.0f;    // 0 x
    verts[1] = Len;     // 0 y
    verts[2] = 0.0f;    // 0 z
    verts[3] = 0.5f;    // 0 s
    verts[4] = 1.0f;    // 0 t
    currentVertex++;

    verts[5] = 0.0f;    // 1 x
    verts[6] = 0.0f;    // 1 y
    verts[7] = 0.0f;    // 1 z
    verts[8] = 0.0f;    // 1 s
    verts[9] = 0.0f;    // 1 t
    currentVertex++;

    // variable to keep track of every triangle added to indices
    int currentTriangle = 0;

    // note: the number of flat sides is equal to the number of edge on the sides
    for (int edge = 0; edge < numSides; edge++)
    {
        // calculate theta, which is the angle from the center point to the next vertex
        float theta = ((float)edge) * radiansPerSide;

        // base triangle first perimeter vertex (only base triangle vertices needed for cone)
        verts[currentVertex * STRIDE + 0] = radius * cos(theta);    // x
        verts[currentVertex * STRIDE + 1] = 0.0f;                   // y
        verts[currentVertex * STRIDE + 2] = radius * sin(theta);    // z
        verts[currentVertex * STRIDE + 3] = (float)edge / (float)numSides;  // s
        verts[currentVertex * STRIDE + 4] = 0.0f;                   // t
        currentVertex++;

        if (edge > 0)
        {
            // now to create the indices for the triangles
            // face triangle
            indices[(3 * currentTriangle) + 0] = 0;                 
            indices[(3 * currentTriangle) + 1] = currentVertex - 2; 
            indices[(3 * currentTriangle) + 2] = currentVertex - 1; 
            currentTriangle++;

            // base triangle
            indices[(3 * currentTriangle) + 0] = 1;                
            indices[(3 * currentTriangle) + 1] = currentVertex - 2; 
            indices[(3 * currentTriangle) + 2] = currentVertex - 1; 
            currentTriangle++;
        }
    }

    // now, just need to wire up the last side
    // now to create the indices for the triangles
    // face triangle
    indices[(3 * currentTriangle) + 0] = 0;                 
    indices[(3 * currentTriangle) + 1] = currentVertex - 1; 
    indices[(3 * currentTriangle) + 2] = 2;                 
    currentTriangle++;

    // base triangle
    indices[(3 * currentTriangle) + 0] = 1;                 
    indices[(3 * currentTriangle) + 1] = currentVertex - 1; 
    indices[(3 * currentTriangle) + 2] = 2;                 
    currentTriangle++;
}


// Code for creating Cone mesh
void UCreateConeMesh(GLMesh& mesh) {

    // Number of sides for base of cone
    const int NUM_SIDES = 100;

    // Number of vertices (Number of sides plus top and bottom point * Stride)
    const int NUM_VERTICES = STRIDE * (2 + NUM_SIDES);

    // Number of indices (2 Triangles per side/slice, base + face)
    const int NUM_INDICES = 6 * NUM_SIDES;

    // Position and Texture data
    GLfloat verts[NUM_VERTICES];

    // Index data
    GLushort indices[NUM_INDICES];

    // Pass vertices and indices data along with radius and length (height) of cone
    UCreateCone(verts, indices, NUM_SIDES, 0.3f, 0.5f);

    // Verify stride is correct
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;
    if (STRIDE != floatsPerVertex + floatsPerUV) {
        exit(EXIT_FAILURE);
    }

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);

}


// Code for creating Plane mesh
void UCreatePlaneMesh(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        // Vertex Positions    // Textures
         0.5f,  0.0f,  1.5f,   1.0f, 0.0f, // Front right vertex 0
         0.5f,  0.0f, -1.5f,   1.0f, 1.0f, // Back right vertex 1
        -0.5f,  0.0f, -1.5f,   0.0f, 1.0f, // Back left vertex 2
        -0.5f,  0.0f,  1.5f,   0.0f, 0.0f, // Front left vertex 3
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 2,  // Triangle 1
        0, 2, 3,   // Triangle 2
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 4 (x, y, z, texCoord1, texCoord2)
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
}


// Code for creating Cube mesh
void UCreateCubeMesh(GLMesh& mesh) {

    // Vertex daya
    GLfloat verts[] = {
        // Vertex Positions   // Texture Coordinates
        -0.5f, 0.001f, -0.5f,  0.0f, 0.0f,
         0.5f, 0.001f, -0.5f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
        -0.5f, 0.001f, -0.5f,  0.0f, 0.0f,

        -0.5f, 0.001f,  0.5f,  0.0f, 0.0f,
         0.5f, 0.001f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
        -0.5f, 0.001f,  0.5f,  0.0f, 0.0f,

        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        -0.5f, 0.001f, -0.5f,  0.0f, 1.0f,
        -0.5f, 0.001f, -0.5f,  0.0f, 1.0f,
        -0.5f, 0.001f,  0.5f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
         0.5f, 0.001f, -0.5f,  0.0f, 1.0f,
         0.5f, 0.001f, -0.5f,  0.0f, 1.0f,
         0.5f, 0.001f,  0.5f,  0.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

        -0.5f, 0.001f, -0.5f,  0.0f, 1.0f,
         0.5f, 0.001f, -0.5f,  1.0f, 1.0f,
         0.5f, 0.001f,  0.5f,  1.0f, 0.0f,
         0.5f, 0.001f,  0.5f,  1.0f, 0.0f,
        -0.5f, 0.001f,  0.5f,  0.0f, 0.0f,
        -0.5f, 0.001f, -0.5f,  0.0f, 1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create VBO
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, mesh.vbos);
}


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
