/*
* Chris Bowles
* CS-330-R3329
* 2/18/24
*
* Module 6-5: This project uses source code from the previous module's milestone, the Meshes_Example
* solution provided in this week's announcements, as well as code from tutorial_06_03. 
* 
* It is meant to show how lighting can affect a scene by applying both directional and point lighting. 
* The directional lighting is meant to give a general light to the whole setting (emanates from the top
* of the scene) and the point lighting is meant to express how light coming from a direct source can
* affect the appearance of objects.
* 
* Our scene specifically includes a light source in the forefront that is meant to emulate sunlight.
* Through using the Phong model and specular lighting specifically, we get reflections on our surfaces
* that we can see as we pan the camera around the scene (both the stone on the wall and the grass). 
* The point lighting also has the affect of making surfaces close to the light source bright and those 
* farther away are darker.
* 
* Current issues I am facing are getting the textures on the cylinders and cones to properly sample.
* From running the code, we can see that it is sampling the general color of the texture only. I 
* believe that so far, the normals for these objects are adequate as lighting seems to be reflecting
* in the proper direction.
*
* Credit for Blue roof texture goes to: Althaj (https://opengameart.org/content/blue-roof)
* 
*/

#include <glad/glad.h>

#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION

#include "stb_image.h"

#include <glm/glm.hpp>

#include <glm/gtc/matrix_transform.hpp>

#include <glm/gtx/transform.hpp>

#include <glm/gtc/type_ptr.hpp>

#include "shader.h"

#include "camera.h"

#include <iostream>

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Module 6-5"; // Macro for window title

    // offset to use to encompass vertex position (3), normals (3) and textures (2)
    const int STRIDE = 8;

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handle for the vertex buffer object(s)
        GLuint nIndices;    // Number of indices of the mesh
        GLuint nVertices;   // Number of vertices (for some meshes)
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // Meshes
    GLMesh gPlaneMesh, gCubeMesh, gCylinderMesh, gConeMesh;

    // Texture
    GLuint gTextureId1, gTextureId2, gTextureId3, gTextureId4, gTextureId5, cubemapTexture;
    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader program
    GLuint gProgramId, gLampProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.5f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // For perspective/orthographic projection switch
    bool perspectiveSwitch = true;

}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreatePrism(GLfloat verts[], GLushort indices[], int numSides, float radius, float halfLen);
void UCreateCylinderMesh(GLMesh& mesh);
void UCreateCone(GLfloat verts[], GLushort indices[], int numSides, float radius, float Len);
void UCreateConeMesh(GLMesh& mesh);
void UCreatePlaneMesh(GLMesh& mesh);
void UCreateCubeMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Cube Vertex Shader Source Code*/
const GLchar* cubeVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
    layout(location = 1) in vec3 normal; // VAP position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
        vertexTextureCoordinate = textureCoordinate;
        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)
        vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    }
);


/* Cube Fragment Shader Source Code*/
const GLchar* cubeFragmentShaderSource = GLSL(440,

    struct Material {
    sampler2D diffuse;
    sampler2D specular;
    float shininess;
};

    struct DirLight {
        vec3 direction;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    struct PointLight {
        vec3 position;

        float constant;
        float linear;
        float quadratic;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    struct SpotLight {
        vec3 position;
        vec3 direction;
        float cutOff;
        float outerCutOff;

        float constant;
        float linear;
        float quadratic;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
    };

    in vec3 vertexNormal; // For incoming normals
    in vec3 vertexFragmentPos; // For incoming fragment position
    in vec2 vertexTextureCoordinate;

    out vec4 fragmentColor; // For outgoing cube color to the GPU

    uniform vec3 viewPosition;
    uniform DirLight dirLight;
    uniform PointLight pointLight;
    uniform SpotLight spotLight;
    uniform Material material;

    uniform sampler2D extraTex;
    uniform bool multipleTextures;
    uniform vec2 uvScale;

    // function prototypes
    vec3 CalcDirLight(DirLight light, vec3 vertexNormal, vec3 viewDir);
    vec3 CalcPointLight(PointLight light, vec3 vertexNormal, vec3 vertexFragmentPos, vec3 viewDir);
    vec3 CalcSpotLight(SpotLight light, vec3 vertexNormal, vec3 vertexFragmentPos, vec3 viewDir);

    void main()
    {
        // properties
        vec3 norm = normalize(vertexNormal);
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos);

        // == =====================================================
        // Our lighting is set up in 3 phases: directional, point lights and an optional flashlight
        // For each phase, a calculate function is defined that calculates the corresponding color
        // per lamp. In the main() function we take all the calculated colors and sum them up for
        // this fragment's final color.
        // == =====================================================
        // phase 1: directional lighting
        vec3 result = CalcDirLight(dirLight, norm, viewDir);
        // phase 2: calculate a point light
        result += CalcPointLight(pointLight, norm, vertexFragmentPos, viewDir);
        // phase 3: spot light (note: commented this out for the time being)
        //result += CalcSpotLight(spotLight, norm, vertexFragmentPos, viewDir);

        fragmentColor = vec4(result, 1.0);
        // Checks bool for multiple textures, applies scale to second incoming texture and outputs color
        if (multipleTextures) {
            vec4 extraTexture = texture(extraTex, vertexTextureCoordinate * uvScale);
            if (extraTexture.a != 0.0) {
                fragmentColor = extraTexture;
            }
        }
    }

    // calculates the color when using a directional light.
    vec3 CalcDirLight(DirLight light, vec3 vertexNormal, vec3 viewDir)
    {
        vec3 lightDir = normalize(-light.direction);
        // diffuse shading
        float diff = max(dot(vertexNormal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, vertexNormal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // combine results
        vec3 ambient = light.ambient * vec3(texture(material.diffuse, vertexTextureCoordinate * uvScale));
        vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, vertexTextureCoordinate * uvScale));
        vec3 specular = light.specular * spec * vec3(texture(material.specular, vertexTextureCoordinate * uvScale));
        return (ambient + diffuse + specular);
    }

    // calculates the color when using a point light.
    vec3 CalcPointLight(PointLight light, vec3 vertexNormal, vec3 vertexFragmentPos, vec3 viewDir)
    {
        vec3 lightDir = normalize(light.position - vertexFragmentPos);
        // diffuse shading
        float diff = max(dot(vertexNormal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, vertexNormal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // attenuation
        float distance = length(light.position - vertexFragmentPos);
        float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
        // combine results
        vec3 ambient = light.ambient * vec3(texture(material.diffuse, vertexTextureCoordinate * uvScale));
        vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, vertexTextureCoordinate * uvScale));
        vec3 specular = light.specular * spec * vec3(texture(material.specular, vertexTextureCoordinate * uvScale));
        ambient *= attenuation;
        diffuse *= attenuation;
        specular *= attenuation;
        return (ambient + diffuse + specular);
    }

    // calculates the color when using a spot light.
    vec3 CalcSpotLight(SpotLight light, vec3 vertexNormal, vec3 vertexFragmentPos, vec3 viewDir)
    {
        vec3 lightDir = normalize(light.position - vertexFragmentPos);
        // diffuse shading
        float diff = max(dot(vertexNormal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, vertexNormal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // attenuation
        float distance = length(light.position - vertexFragmentPos);
        float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
        // spotlight intensity
        float theta = dot(lightDir, normalize(-light.direction));
        float epsilon = light.cutOff - light.outerCutOff;
        float intensity = clamp((theta - light.outerCutOff) / epsilon, 0.0, 1.0);
        // combine results
        vec3 ambient = light.ambient * vec3(texture(material.diffuse, vertexTextureCoordinate));
        vec3 diffuse = light.diffuse * diff * vec3(texture(material.diffuse, vertexTextureCoordinate));
        vec3 specular = light.specular * spec * vec3(texture(material.specular, vertexTextureCoordinate));
        ambient *= attenuation * intensity;
        diffuse *= attenuation * intensity;
        specular *= attenuation * intensity;
        return (ambient + diffuse + specular);
    }
);


/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);


/* Lamp Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

    void main()
    {
        fragmentColor = vec4(1.0f, 1.0f, 0.5f, 1.0f); // Set color to yellow with alpha 1.0
    }
);


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create meshes
    UCreatePlaneMesh(gPlaneMesh);
    UCreateCubeMesh(gCubeMesh);
    UCreateCylinderMesh(gCylinderMesh);
    UCreateConeMesh(gConeMesh);

    // Create the shader program
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Load textures
    const char* texFilename = "grass.jpg";
    if (!UCreateTexture(texFilename, gTextureId1))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    const char* tex2Filename = "dirt_path.png";
    if (!UCreateTexture(tex2Filename, gTextureId2))
    {
        cout << "Failed to load texture " << tex2Filename << endl;
        return EXIT_FAILURE;
    }

    const char* tex3Filename = "stone.jpg";
    if (!UCreateTexture(tex3Filename, gTextureId3))
    {
        cout << "Failed to load texture " << tex3Filename << endl;
        return EXIT_FAILURE;
    }

    const char* tex4Filename = "blue_roof.png";
    if (!UCreateTexture(tex4Filename, gTextureId4))
    {
        cout << "Failed to load texture " << tex4Filename << endl;
        return EXIT_FAILURE;
    }

    const char* tex5Filename = "wood_material.jpg";
    if (!UCreateTexture(tex5Filename, gTextureId5))
    {
        cout << "Failed to load texture " << tex5Filename << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gProgramId);

    GLint material_diffuseLoc = glGetUniformLocation(gProgramId, "material.diffuse");
    GLint material_specularLoc = glGetUniformLocation(gProgramId, "material.specular");
    GLint extraTex = glGetUniformLocation(gProgramId, "extraTex");

    glUniform1i(material_diffuseLoc, 0);
    glUniform1i(material_specularLoc, 1);
    glUniform1i(extraTex, 2);


    // Sets grey background color
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);

    // Render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Check key callback (Projection switch, etc.)
        glfwSetKeyCallback(gWindow, key_callback);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gCubeMesh);
    UDestroyMesh(gCylinderMesh);
    UDestroyMesh(gConeMesh);

    // Release texture
    UDestroyTexture(gTextureId1);
    UDestroyTexture(gTextureId2);
    UDestroyTexture(gTextureId3);
    UDestroyTexture(gTextureId4);
    UDestroyTexture(gTextureId5);

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLampProgramId);

    // Exits program
    exit(EXIT_SUCCESS); 
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers

    // ---------------------------------------

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))

    {

        std::cout << "Failed to initialize GLAD" << std::endl;

        return -1;

    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    // Implementing code for key presses 'Q' and 'E' for up and down camera movement respectively
    /* Modifying code in camera.h as follows to calculate for camera position:
    *
    * if (direction == UP)
            Position += Up * velocity;
        if (direction == DOWN)
            Position -= Up * velocity;
    */

    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
}


// callback function executes in main loop; checks for certain key events
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_P && action == GLFW_PRESS) {
        // COUT statements for testing purpose
        cout << "P pressed" << endl;
        // Switches boolean value to opposite of current value
        if (perspectiveSwitch == true) {
            perspectiveSwitch = false;
            cout << "projection switched to orthographic" << endl;
        }
        else if (perspectiveSwitch == false) {
            perspectiveSwitch = true;
            cout << "projection switched back to perspective" << endl;
        }
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    // ProcessMouseScroll() function now determines movement speed of camera; commented changes in camera.h file
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Function called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // set the camera position for the shader to use
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // set the material shininess
    GLint material_shininessLoc = glGetUniformLocation(gProgramId, "material.shininess");
    glUniform1f(material_shininessLoc, 32.0f);

    // set up the directional light for the scene
    GLint dirLight_directionLoc = glGetUniformLocation(gProgramId, "dirLight.direction");
    GLint dirLight_ambientLoc = glGetUniformLocation(gProgramId, "dirLight.ambient");
    GLint dirLight_diffuseLoc = glGetUniformLocation(gProgramId, "dirLight.diffuse");
    GLint dirLight_specularLoc = glGetUniformLocation(gProgramId, "dirLight.specular");

    // pass direction and light data to the shader program's corresponding uniforms
    glUniform3f(dirLight_directionLoc, -0.2f, -1.0f, -0.3f);
    glUniform3f(dirLight_ambientLoc, 0.05f, 0.05f, 0.05f);
    glUniform3f(dirLight_diffuseLoc, 0.4f, 0.4f, 0.4f);
    glUniform3f(dirLight_specularLoc, 0.5f, 0.5f, 0.5f);

    // set up the point light for the scene
    GLint pointLight_positionLoc = glGetUniformLocation(gProgramId, "pointLight.position");
    GLint pointLight_ambientLoc = glGetUniformLocation(gProgramId, "pointLight.ambient");
    GLint pointLight_diffuseLoc = glGetUniformLocation(gProgramId, "pointLight.diffuse");
    GLint pointLight_specularLoc = glGetUniformLocation(gProgramId, "pointLight.specular");
    GLint pointLight_constantLoc = glGetUniformLocation(gProgramId, "pointLight.constant");
    GLint pointLight_linearLoc = glGetUniformLocation(gProgramId, "pointLight.linear");
    GLint pointLight_quadraticLoc = glGetUniformLocation(gProgramId, "pointLight.quadratic");

    // pass point light data to the shader program's corresponding uniforms
    glUniform3f(pointLight_positionLoc, -1.0f, 2.0f, 1.0f);
    glUniform3f(pointLight_ambientLoc, 0.05f, 0.05f, 0.05f);
    glUniform3f(pointLight_diffuseLoc, 0.8f, 0.8f, 0.8f);
    glUniform3f(pointLight_specularLoc, 1.0f, 1.0f, 1.0f);
    glUniform1f(pointLight_constantLoc, 1.0f);
    glUniform1f(pointLight_linearLoc, 0.09f);
    glUniform1f(pointLight_quadraticLoc, 0.032f);

    // 1. Scale the object
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates shape by 0 degrees in all axes
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Place object at origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // Transforms the camera: move the camera up (y axis) and back (z axis)
    glm::mat4 view = gCamera.GetViewMatrix();
    
    // If statement to capture the projection matrix desired (defaults to perspective)
    // Bool value 'perspectiveSwitch' is determined in the key_callback() function
    glm::mat4 projection;
    if (perspectiveSwitch == true) {
        // Creates a perspective projection
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else {
        // Creates an orthographic projection
        projection = glm::ortho(-4.0f, 4.0f, -4.0f, 4.0f, 0.1f, 50.0f);
    }

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Points to Texture scale we declared in namespace
    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Activate boolean that identifies multiple textures
    // This lets the fragment shader know that we are working with multiple textures
    GLuint multipleTexturesLoc = glGetUniformLocation(gProgramId, "multipleTextures");
    glUniform1i(multipleTexturesLoc, true);


    ////////////
    // PLANES //
    ////////////

    // ACtivate VAO
    glBindVertexArray(gPlaneMesh.vao);

    // Bind Grass texture to diffuse and specular textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId1);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId1); 

    // Bind Dirt texture to extra texture layer
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureId2);

    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Deactivate texture
    glBindTexture(GL_TEXTURE_2D, 0);

    // Activate boolean that identifies multiple textures (TOGGLE OFF)
    glUniform1i(multipleTexturesLoc, false);

    // Surrounding grass, translate and draw
    translation = glm::translate(glm::vec3(-1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    translation = glm::translate(glm::vec3(1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Deactivate textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Deactivate VAO
    glBindVertexArray(0);

    // END PLANES //
    
    ///////////
    // CUBES //
    ///////////

    // Activate VAO
    glBindVertexArray(gCubeMesh.vao);

    // Transformations
    translation = glm::translate(glm::vec3(-1.0f, 0.0f, 0.0f));
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 0.5f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale up textures
    gUVScale = glm::vec2(10.0f, 5.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Bind Stone texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId3); 

    // Render
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Transformations
    translation = glm::translate(glm::vec3(1.0f, 0.0f, 0.0f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Render
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Transformations
    translation = glm::translate(glm::vec3(0.0f, 0.5f, 0.0f));
    scale = glm::scale(glm::vec3(1.05f, 0.05f, 0.45f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Render
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Gates
    // 
    // Reset texture scale
    gUVScale = glm::vec2(1.0f, 1.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Transformations
    translation = glm::translate(glm::vec3(-0.475f, 0.0f, 0.25f));
    scale = glm::scale(glm::vec3(0.05f, 1.0f, 0.5f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Bind Stone texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId5);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId5);

    // Render
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Transformations
    translation = glm::translate(glm::vec3(0.475f, 0.0f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Render
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Deactivate textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, 0);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Reset texture scale
    gUVScale = glm::vec2(1.0f, 1.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Switch to Lamp Shader Program
    glUseProgram(gLampProgramId);

    // LAMP LIGHT (translate to point light origin and scale down)
    translation = glm::translate(glm::vec3(-1.0f, 2.0f, 1.0f));
    scale = glm::scale(glm::vec3(0.2f, 0.4f, 0.2f));
    model = translation * rotation * scale;

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Deactivate VAO
    glBindVertexArray(0);

    // END CUBES //

    ///////////////
    // CYLINDERS //
    ///////////////

    // Switch Shader Program
    glUseProgram(gProgramId);

    // Activate VAO
    glBindVertexArray(gCylinderMesh.vao);
    
    // Scale and Translate
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    translation = glm::translate(glm::vec3(0.75f, 0.501f, 0.25f));
    model = translation * rotation * scale;

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Scale textures
    gUVScale = glm::vec2(8.0f, 10.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Bind textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate second cylinder
    rotation = glm::rotate(90.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    translation = glm::translate(glm::vec3(-0.75f, 0.501f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate third cylinder
    scale = glm::scale(glm::vec3(1.0f, 0.6f, 1.0f));
    translation = glm::translate(glm::vec3(1.3f, 0.301f, 0.2f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale textures
    gUVScale = glm::vec2(8.0f, 6.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Scale and Translate fourth cylinder
    translation = glm::translate(glm::vec3(-1.3f, 0.301f, 0.2f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gCylinderMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Deactivate textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId3);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // END CYLINDERS //
        

    ///////////
    // CONES //
    ///////////

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gConeMesh.vao);

    // Scale and Translate
    translation = glm::translate(glm::vec3(0.75f, 1.001f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Scale textures
    gUVScale = glm::vec2(3.0f, 2.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Bind textures
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureId4);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureId4);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gConeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);


    // Scale and Translate
    translation = glm::translate(glm::vec3(-0.75f, 1.001f, 0.25f));
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gConeMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    // Reset texture scale
    gUVScale = glm::vec2(1.0f, 1.0f);
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    //// END CONES //

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// creates a prism based on the number of side turned in; assumes a stride of 8
void UCreatePrism(GLfloat verts[], GLushort indices[], int numSides, float radius, float halfLen)
{
    // create constant for 2PI used in calculations
    const float TWO_PI = 2.0f * 3.1415926f;
    const float radiansPerSide = TWO_PI / numSides;

    // value to increment after each vertex is created
    int currentVertex = 0;

    // in this  algorithm, vertex zero is the top center vertex, and vertex one is the bottom center
    // each is offset by the step size
    verts[0] = 0.0f;    // 0 x
    verts[1] = halfLen; // 0 y
    verts[2] = 0.0f;    // 0 z
    verts[3] = 0.0f;    // 0 xNorm
    verts[4] = 1.0f;    // 0 yNorm
    verts[5] = 0.0f;    // 0 zNorm
    verts[6] = 1.0f;    // 0 s
    verts[7] = 1.0f;    // 0 t
    currentVertex++;

    verts[8] = 0.0f;    // 1 x
    verts[9] = -halfLen;// 1 y
    verts[10] = 0.0f;   // 1 z
    verts[11] = 0.0f;   // 1 xNorm
    verts[12] = -1.0f;   // 1 yNorm
    verts[13] = 0.0f;   // 1 zNorm
    verts[14] = 0.0f;   // 1 s
    verts[15] = 0.0f;   // 1 t
    currentVertex++;

    // variable to keep track of every triangle added to indices
    int currentTriangle = 0;

    // note: the number of flat sides is equal to the number of edge on the sides
    for (int edge = 0; edge < numSides; edge++)
    {
        // calculate theta, which is the angle from the center point to the next vertex
        float theta = ((float)edge) * radiansPerSide;

        // top triangle first perimeter vertex
        verts[currentVertex * STRIDE + 0] = radius * cos(theta);    // x
        verts[currentVertex * STRIDE + 1] = halfLen;                // y
        verts[currentVertex * STRIDE + 2] = radius * sin(theta);    // z
        verts[currentVertex * STRIDE + 3] = cos(theta + radiansPerSide / 2);                   // xNorm
        verts[currentVertex * STRIDE + 4] = 0.0f;                   // yNorm
        verts[currentVertex * STRIDE + 5] = sin(theta + radiansPerSide / 2);                  // zNorm
        verts[currentVertex * STRIDE + 6] = (float)edge / (float)numSides;  // s
        verts[currentVertex * STRIDE + 7] = 0.0f;                   // t
        currentVertex++;

        // bottom triangle first perimeter vertex
        verts[currentVertex * STRIDE + 0] = radius * cos(theta);    // x
        verts[currentVertex * STRIDE + 1] = -halfLen;               // y
        verts[currentVertex * STRIDE + 2] = radius * sin(theta);    // z
        verts[currentVertex * STRIDE + 3] = cos(theta + radiansPerSide / 2);
        verts[currentVertex * STRIDE + 4] = 0.0f;
        verts[currentVertex * STRIDE + 5] = sin(theta + radiansPerSide / 2);
        verts[currentVertex * STRIDE + 6] = (float)edge / (float)numSides;  // s
        verts[currentVertex * STRIDE + 7] = 1.0f;                   // t
        currentVertex++;

        if (edge > 0)
        {
            // now to create the indices for the triangles
            // top triangle
            indices[(3 * currentTriangle) + 0] = 0;                 // center of top of prism
            indices[(3 * currentTriangle) + 1] = currentVertex - 4; // upper left vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 2; // upper right vertex of side
            currentTriangle++;

            // bottom triangle
            indices[(3 * currentTriangle) + 0] = 1;                 // center of bottom of prism
            indices[(3 * currentTriangle) + 1] = currentVertex - 3; // bottom left vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 1; // bottom right vertex of side
            currentTriangle++;

            // triangle for 1/2 retangular side
            indices[(3 * currentTriangle) + 0] = currentVertex - 4; // upper left vertex of side
            indices[(3 * currentTriangle) + 1] = currentVertex - 3; // bottom left vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 1; // bottom right vertex of side
            currentTriangle++;

            // triangle for second 1/2 retangular side
            indices[(3 * currentTriangle) + 0] = currentVertex - 1; // bottom right vertex of side
            indices[(3 * currentTriangle) + 1] = currentVertex - 2; // upper right vertex of side
            indices[(3 * currentTriangle) + 2] = currentVertex - 4; // upper left vertex of side
            currentTriangle++;

        }

    }

    // now, just need to wire up the last side
    // now to create the indices for the triangles
    // top triangle
    indices[(3 * currentTriangle) + 0] = 0;                 // center of top of prism
    indices[(3 * currentTriangle) + 1] = currentVertex - 2; // upper left vertex of side
    indices[(3 * currentTriangle) + 2] = 2;                 // first upper left vertex created, now right
    currentTriangle++;

    // bottom triangle
    indices[(3 * currentTriangle) + 0] = 1;                 // center of bottom of prism
    indices[(3 * currentTriangle) + 1] = currentVertex - 1; // bottom left vertex of side
    indices[(3 * currentTriangle) + 2] = 3;                 // first bottom left vertex created, now right
    currentTriangle++;

    // triangle for 1/2 retangular side
    indices[(3 * currentTriangle) + 0] = currentVertex - 2; // upper left vertex of side
    indices[(3 * currentTriangle) + 1] = currentVertex - 1; // bottom left vertex of side
    indices[(3 * currentTriangle) + 2] = 3;                 // bottom right vertex of side
    currentTriangle++;

    // triangle for second 1/2 retangular side
    indices[(3 * currentTriangle) + 0] = 3;                 // bottom right vertex of side
    indices[(3 * currentTriangle) + 1] = 2;                 // upper right vertex of side
    indices[(3 * currentTriangle) + 2] = currentVertex - 2; // upper left vertex of side
    currentTriangle++;

}


// Code for creating Cylinder (rectangular prism w many sides) mesh; Updated for sending Normals
void UCreateCylinderMesh(GLMesh& mesh) {

    // Number of sides for prism
    const int NUM_SIDES = 100;

    // Number of vertices
    const int NUM_VERTICES = STRIDE * (2 + (2 * NUM_SIDES));

    // Number of indices
    const int NUM_INDICES = 12 * NUM_SIDES;

    // Position and Texture data
    GLfloat verts[NUM_VERTICES];

    // Index data
    GLushort indices[NUM_INDICES];

    // Fill verts and indices arrays
    UCreatePrism(verts, indices, NUM_SIDES, 0.2f, 0.5f);

    // Verify stride is correct
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;
    if (STRIDE != floatsPerVertex + floatsPerNormal + floatsPerUV) {
        exit(EXIT_FAILURE);
    }

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


// Creates a cone based on the number of sides, also assumes stride of 8
void UCreateCone(GLfloat verts[], GLushort indices[], int numSides, float radius, float Len) {

    // create constant for 2PI used in calculations
    const float TWO_PI = 2.0f * 3.1415926f;
    const float radiansPerSide = TWO_PI / numSides;

    // value to increment after each vertex is created
    int currentVertex = 0;

    // in this  algorithm, vertex zero is the top center vertex, and vertex one is the bottom center
    // each is offset by the step size
    verts[0] = 0.0f;    // 0 x
    verts[1] = Len;     // 0 y
    verts[2] = 0.0f;    // 0 z
    verts[3] = 0.0f;    // 0 xN
    verts[4] = 1.0f;    // 0 yN
    verts[5] = 0.0f;    // 0 zN
    verts[6] = 0.5f;    // 0 s
    verts[7] = 1.0f;    // 0 t
    currentVertex++;

    verts[8] = 0.0f;    // 1 x
    verts[9] = 0.0f;    // 1 y
    verts[10] = 0.0f;    // 1 z
    verts[11] = 0.0f;   // 1 xN
    verts[12] = -1.0f;  // 1 yN
    verts[13] = 0.0f;   // 1 zN
    verts[14] = 0.0f;    // 1 s
    verts[15] = 0.0f;    // 1 t
    currentVertex++;

    // variable to keep track of every triangle added to indices
    int currentTriangle = 0;

    // note: the number of flat sides is equal to the number of edge on the sides
    for (int edge = 0; edge < numSides; edge++)
    {
        // calculate theta, which is the angle from the center point to the next vertex
        float theta = ((float)edge) * radiansPerSide;

        // base triangle first perimeter vertex (only base triangle vertices needed for cone)
        verts[currentVertex * STRIDE + 0] = radius * cos(theta);    // x
        verts[currentVertex * STRIDE + 1] = 0.0f;                   // y
        verts[currentVertex * STRIDE + 2] = radius * sin(theta);    // z
        verts[currentVertex * STRIDE + 3] = cos(theta + radiansPerSide / 2);
        verts[currentVertex * STRIDE + 4] = 0.0f;
        verts[currentVertex * STRIDE + 5] = sin(theta + radiansPerSide / 2);
        verts[currentVertex * STRIDE + 6] = (float)edge / (float)numSides;  // s
        verts[currentVertex * STRIDE + 7] = 0.0f;                   // t
        currentVertex++;

        if (edge > 0)
        {
            // now to create the indices for the triangles
            // face triangle
            indices[(3 * currentTriangle) + 0] = 0;
            indices[(3 * currentTriangle) + 1] = currentVertex - 2;
            indices[(3 * currentTriangle) + 2] = currentVertex - 1;
            currentTriangle++;

            // base triangle
            indices[(3 * currentTriangle) + 0] = 1;
            indices[(3 * currentTriangle) + 1] = currentVertex - 2;
            indices[(3 * currentTriangle) + 2] = currentVertex - 1;
            currentTriangle++;
        }
    }

    // now, just need to wire up the last side
    // now to create the indices for the triangles
    // face triangle
    indices[(3 * currentTriangle) + 0] = 0;
    indices[(3 * currentTriangle) + 1] = currentVertex - 1;
    indices[(3 * currentTriangle) + 2] = 2;
    currentTriangle++;

    // base triangle
    indices[(3 * currentTriangle) + 0] = 1;
    indices[(3 * currentTriangle) + 1] = currentVertex - 1;
    indices[(3 * currentTriangle) + 2] = 2;
    currentTriangle++;
}


// Code for creating Cone mesh; Updated for sending Normals to shaders
void UCreateConeMesh(GLMesh& mesh) {

    // Number of sides for base of cone
    const int NUM_SIDES = 100;

    // Number of vertices (Number of sides plus top and bottom point * Stride)
    const int NUM_VERTICES = STRIDE * (2 + NUM_SIDES);

    // Number of indices (2 Triangles per side/slice, base + face)
    const int NUM_INDICES = 6 * NUM_SIDES;

    // Position and Texture data
    GLfloat verts[NUM_VERTICES];

    // Index data
    GLushort indices[NUM_INDICES];

    // Pass vertices and indices data along with radius and length (height) of cone
    UCreateCone(verts, indices, NUM_SIDES, 0.3f, 0.5f);

    // Verify stride is correct
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;
    if (STRIDE != floatsPerVertex + floatsPerNormal + floatsPerUV) {
        exit(EXIT_FAILURE);
    }

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU
    mesh.nVertices = sizeof(verts) / sizeof(verts[0]);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

}


// Code for creating Plane mesh; Updated for sending Normals to shaders
void UCreatePlaneMesh(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        // Vertex Positions  // Vertex Normals     // Textures
         0.5f,  0.0f,  1.5f,  0.0f,  1.0f,  0.0f,   1.0f, 0.0f, // Front right vertex 0
         0.5f,  0.0f, -1.5f,  0.0f,  1.0f,  0.0f,   1.0f, 1.0f, // Back right vertex 1
        -0.5f,  0.0f, -1.5f,  0.0f,  1.0f,  0.0f,   0.0f, 1.0f, // Back left vertex 2
        -0.5f,  0.0f,  1.5f,  0.0f,  1.0f,  0.0f,   0.0f, 0.0f, // Front left vertex 3
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 2,  // Triangle 1
        0, 2, 3,   // Triangle 2
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 7 (x, y, z, x2, y2, z2, texCoord1, texCoord2)
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


// Code for creating Cube mesh; Updated for sending Normals to shaders
void UCreateCubeMesh(GLMesh& mesh) {

    // Vertex daya
    GLfloat verts[] = {
        // Vertex Positions    // Vertex Normals     // Texture Coordinates
        // Back face
        -0.5f, 0.001f, -0.5f,  0.0f,  0.0f,  -1.0f,  0.0f,  0.0f,
         0.5f, 0.001f, -0.5f,  0.0f,  0.0f,  -1.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f,  -1.0f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f,  -1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f,  -1.0f,  0.0f, 1.0f,
        -0.5f, 0.001f, -0.5f,  0.0f,  0.0f,  -1.0f,  0.0f, 0.0f,
        // Front face
        -0.5f, 0.001f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
         0.5f, 0.001f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f,
        -0.5f, 0.001f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f,
        // Left face
        -0.5f,  0.5f,  0.5f,  -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,
        -0.5f, 0.001f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, 0.001f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,
        -0.5f, 0.001f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,
        // Right face
         0.5f,  0.5f,  0.5f,   1.0f,  0.0f,  0.0f,   1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,   1.0f,  0.0f,  0.0f,   1.0f, 1.0f,
         0.5f, 0.001f, -0.5f,  1.0f,  0.0f,  0.0f,   0.0f, 1.0f,
         0.5f, 0.001f, -0.5f,  1.0f,  0.0f,  0.0f,   0.0f, 1.0f,
         0.5f, 0.001f,  0.5f,  1.0f,  0.0f,  0.0f,   0.0f, 0.0f,
         0.5f,  0.5f,  0.5f,   1.0f,  0.0f,  0.0f,   1.0f, 0.0f,
        // Bottom face
        -0.5f, 0.001f, -0.5f,  0.0f, -1.0f,  0.0f,   0.0f, 1.0f,
         0.5f, 0.001f, -0.5f,  0.0f, -1.0f,  0.0f,   1.0f, 1.0f,
         0.5f, 0.001f,  0.5f,  0.0f, -1.0f,  0.0f,   1.0f, 0.0f,
         0.5f, 0.001f,  0.5f,  0.0f, -1.0f,  0.0f,   1.0f, 0.0f,
        -0.5f, 0.001f,  0.5f,  0.0f, -1.0f,  0.0f,   0.0f, 0.0f,
        -0.5f, 0.001f, -0.5f,  0.0f, -1.0f,  0.0f,   0.0f, 1.0f,
        // Top face
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,   0.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,   1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,   1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,   1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,   0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,   0.0f, 1.0f

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
    mesh.nIndices = 0;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create VBO
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UCreateSkybox(GLMesh& mesh) {

    // Vertex data
    GLfloat verts[] = {
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f,  1.0f,
         1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f,
        -1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f
    };

    // Index data
    GLushort indices[]{
        1, 2, 6,
        6, 5, 1,
        0, 4, 7,
        7, 3, 0,
        4, 5, 6,
        6, 7, 4,
        0, 3, 2,
        2, 1, 0,
        0, 1, 5,
        5, 4, 0,
        3, 7, 6,
        6, 2, 3
    };


}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, mesh.vbos);
}


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}
